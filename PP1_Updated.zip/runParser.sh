#!/usr/bin/env python
# CS564 2018 PP1
# Group members: Meiliu Wu, Chenlai Shi, Xinyi Liu
python TbParser_Modified_Meiliu.py ebay_data/items-*.json