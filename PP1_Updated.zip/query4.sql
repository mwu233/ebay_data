select ItemID from Items
order by Currently DESC
limit 1;